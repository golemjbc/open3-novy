jQuery( document ).ready(function( $ ) {

  "use strict";

  $('.owl-carousel').owlCarousel({
    items:4,
    lazyLoad:true,
    loop:true,
    dots:true,
    margin:20,
    responsiveClass:true,
    responsive:{
      0:{ items:1 },
      600:{ items:2 },
      1000:{ items:4 }
    }
  });

  /* deactivate jquery isotope – necháme jen owl + flexslider */

  /*
  var $container = $('.posts').isotope({
    itemSelector : '.item',
    isFitWidth: true
  });

  $(window).smartresize(function(){
    $container.isotope({
      columnWidth: '.col-sm-3'
    });
  });
  
  $container.isotope({ filter: '*' });

  $('#filters').on( 'click', 'button', function() {
    var filterValue = $(this).attr('data-filter');
    $container.isotope({ filter: filterValue });
  });
  */

  // Flexslider jen pokud je knihovna načtená
  if ($.fn.flexslider) {
    $('#carousel').flexslider({
      animation: "slide",
      controlNav: false,
      animationLoop: false,
      slideshow: false,
      itemWidth: 210,
      itemMargin: 5,
      asNavFor: '#slider'
    });

    /*
    $('#slider').flexslider({
      animation: "slide",
      controlNav: false,
      animationLoop: false,
      slideshow: false,
      sync: "#carousel"
    });
    */
  }

});
